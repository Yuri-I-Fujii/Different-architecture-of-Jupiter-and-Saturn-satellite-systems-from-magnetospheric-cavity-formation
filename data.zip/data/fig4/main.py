import numpy as np
import os
import matplotlib
matplotlib.use('PDF')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import math

DATA_DIR = "./data1"

def _pick_data_subdir(subdir_name: str) -> str:
    """Return ./data/<subdir_name> if it exists, otherwise fall back to ./data.
    This keeps the script working whether files are placed flat in ./data or grouped
    into subfolders like ./data/jupiter, ./data/saturn, ./data/local.
    """
    cand = os.path.join(DATA_DIR, subdir_name)
    return cand if os.path.isdir(cand) else DATA_DIR

DATA_LOCAL = _pick_data_subdir("local")
JUPITER_DIR = _pick_data_subdir("jupiter")
SATURN_DIR = _pick_data_subdir("saturn")


f = plt.figure(figsize=(16, 6))
gs = gridspec.GridSpec(11, 61)
ax1 = plt.subplot(gs[0:11, 0:10])
ax2 = plt.subplot(gs[0:11, 10:20])
ax3 = plt.subplot(gs[0:11, 21:30])
ax4 = plt.subplot(gs[0:11, 31:41])
ax5 = plt.subplot(gs[0:11, 41:51])
ax6 = plt.subplot(gs[0:11, 52:61])

def find_next_available_file(base_path, base_number):
    step = 10
    max_tries = 100000

    for i in range(max_tries):
        filename = f"{base_path}/{base_number + step * i}_snap.dat"
        if os.path.exists(filename):
            return filename
    return None

def find_files(bases):
    found_files = {}
    for base in bases:
        base_path, base_filename = os.path.split(base)
        base_number = int(base_filename.split('_')[0])
        found_file = find_next_available_file(base_path, base_number)
        found_files[base] = found_file  # None if not found
    return found_files


file_name = os.path.join(DATA_LOCAL, "snowline_Jupiter.dat")
if os.path.exists(file_name):
    d1 = np.genfromtxt(file_name)
    t1, rSL1 = d1.T
    ax2.plot(t1, rSL1, lw=1.5, ls='--', c='black', alpha=0.8)
    ax1.plot(t1 + 2e5, rSL1, lw=1.5, ls='--', c='black', alpha=0.8)

file_name = os.path.join(DATA_LOCAL, "snowline_Saturn.dat")
if os.path.exists(file_name):
    d1 = np.genfromtxt(file_name)
    t1, rSL1 = d1.T
    ax5.plot(t1, rSL1, lw=1.5, ls='--', c='black', alpha=0.8)
    ax4.plot(t1 + 6e5, rSL1, lw=1.5, ls='--', c='black', alpha=0.8)

num_fig = 400
for i in range(0, num_fig):
    file_name = os.path.join(JUPITER_DIR, f"{i}_plot2.dat")
    if os.path.exists(file_name):
        d1 = np.genfromtxt(file_name)
        t1, a1, m1 = d1.T
        m1 = 10**m1
        if isinstance(t1, (int, float)):
            t1 = [t1]
        for j in range(len(t1)-1):
            ax1.plot(t1[j:j+2], a1[j:j+2], linewidth='0.5' if m1[j] < 1e-5 else '1.5', linestyle="-", color='#7f7f7f' if m1[j] < 1e-5 else '#1f77b4', alpha=0.5 if m1[j] < 1e-5 else 1.0, zorder=1.0 if m1[j] < 1e-5 else 2.0)

bases = [
    os.path.join(JUPITER_DIR, "3300_snap.dat"),
    os.path.join(JUPITER_DIR, "10000_snap.dat"),
    os.path.join(JUPITER_DIR, "33000_snap.dat"),
    os.path.join(JUPITER_DIR, "100000_snap.dat"),
    os.path.join(JUPITER_DIR, "330000_snap.dat"),
    os.path.join(JUPITER_DIR, "1000000_snap.dat"),
    os.path.join(JUPITER_DIR, "3300000_snap.dat"),
    os.path.join(JUPITER_DIR, "6600000_snap.dat"),
]
found_files = find_files(bases)

for base, found in found_files.items():
    #print(f"{base} -> {found if found else 'Not found'}")
    if not found:
        continue
    d1 = np.genfromtxt(found)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    filtered_t1 = []
    filtered_a1 = []
    filtered_wmf1 = []
    for t, a, w, m in zip(t1, a1, wmf1, m1):
        if m > 1e-5:
            filtered_t1.append(t)
            filtered_a1.append(a)
            filtered_wmf1.append(w)
    ax1.scatter(filtered_t1, filtered_a1, marker='o', c=filtered_wmf1, vmin=0, vmax=0.3, alpha=0.7, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu', zorder=3.0)
    
num_fig = 400
for i in range(0, num_fig):
    file_name = os.path.join(JUPITER_DIR, f"{i}_plot3.dat")
    if os.path.exists(file_name):
        d1 = np.genfromtxt(file_name)
        t1, a1, m1 = d1.T
        m1 = 10**m1
        t1 = t1 - 2e5
        if isinstance(t1, (int, float)):
            t1 = [t1]
        for j in range(len(t1)-1):
            ax2.plot(t1[j:j+2], a1[j:j+2], linewidth='0.5' if m1[j] < 1e-5 else '1.5', linestyle="-", color='#7f7f7f' if m1[j] < 1e-5 else '#1f77b4', alpha=0.5 if m1[j] < 1e-5 else 1.0, zorder=1.0 if m1[j] < 1e-5 else 2.0)

bases = [
    os.path.join(JUPITER_DIR, "6600000_snap.dat"),
    os.path.join(JUPITER_DIR, "6603300_snap.dat"),
    os.path.join(JUPITER_DIR, "6610000_snap.dat"),
    os.path.join(JUPITER_DIR, "6633000_snap.dat"),
    os.path.join(JUPITER_DIR, "6930000_snap.dat"),
    os.path.join(JUPITER_DIR, "7600000_snap.dat"),
    os.path.join(JUPITER_DIR, "9930000_snap.dat"),
    os.path.join(JUPITER_DIR, "13200000_snap.dat"),
]
found_files = find_files(bases)

for base, found in found_files.items():
    #print(f"{base} -> {found if found else 'Not found'}")
    if not found:
        continue
    d1 = np.genfromtxt(found)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    t1 = t1 - 2e5
    filtered_t1 = []
    filtered_a1 = []
    filtered_wmf1 = []
    for t, a, w, m in zip(t1, a1, wmf1, m1):
        if m > 1e-5:
            filtered_t1.append(t)
            filtered_a1.append(a)
            filtered_wmf1.append(w)
    ax2.scatter(filtered_t1, filtered_a1, marker='o', c=filtered_wmf1, vmin=0, vmax=0.3, alpha=0.7, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu', zorder=3.0)
    

file_name = os.path.join(JUPITER_DIR, "13300000_snap.dat")
if os.path.exists(file_name):
    d1 = np.genfromtxt(file_name)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    mappable = ax3.scatter(m1, a1, marker='o', c=wmf1, vmin=0, vmax=0.3, alpha=1.0, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu')  # RdYlBu
else:
    mappable = None

num_fig = 1000
for i in range(0, num_fig):
    file_name = os.path.join(SATURN_DIR, f"{i}_plot2.dat")
    if os.path.exists(file_name):
        d1 = np.genfromtxt(file_name)
        t1, a1, m1 = d1.T
        m1 = 10**m1
        if isinstance(t1, (int, float)):
            t1 = [t1]
        for j in range(len(t1)-1):
            ax4.plot(t1[j:j+2], a1[j:j+2], linewidth='0.5' if m1[j] < 1e-5 else '1.5', linestyle="-", color='#7f7f7f' if m1[j] < 1e-5 else '#1f77b4', alpha=0.5 if m1[j] < 1e-5 else 1.0, zorder=1.0 if m1[j] < 1e-5 else 2.0) #1f77b4

bases = [
    os.path.join(SATURN_DIR, "23000_snap.dat"),
    os.path.join(SATURN_DIR, "77000_snap.dat"),
    os.path.join(SATURN_DIR, "230000_snap.dat"),
    os.path.join(SATURN_DIR, "770000_snap.dat"),
    os.path.join(SATURN_DIR, "2300000_snap.dat"),
    os.path.join(SATURN_DIR, "7700000_snap.dat"),
    os.path.join(SATURN_DIR, "14000000_snap.dat"),
]
found_files = find_files(bases)

for base, found in found_files.items():
    #print(f"{base} -> {found if found else 'Not found'}")
    if not found:
        continue
    d1 = np.genfromtxt(found)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    filtered_t1 = []
    filtered_a1 = []
    filtered_wmf1 = []
    for t, a, w, m in zip(t1, a1, wmf1, m1):
        if m > 1e-5:
            filtered_t1.append(t)
            filtered_a1.append(a)
            filtered_wmf1.append(w)
    ax4.scatter(filtered_t1, filtered_a1, marker='o', c=filtered_wmf1, vmin=0, vmax=0.3, alpha=0.7, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu', zorder=3.0)

num_fig = 1000
for i in range(0, num_fig):
    file_name = os.path.join(SATURN_DIR, f"{i}_plot3.dat")
    if os.path.exists(file_name):
        d1 = np.genfromtxt(file_name)
        t1, a1, m1 = d1.T
        m1 = 10**m1
        t1 = t1 - 6e5
        if isinstance(t1, (int, float)):
            t1 = [t1]
        for j in range(len(t1)-1):
            ax5.plot(t1[j:j+2], a1[j:j+2], linewidth='0.5' if m1[j] < 1e-5 else '1.5', linestyle="-", color='#7f7f7f' if m1[j] < 1e-5 else '#1f77b4', alpha=0.5 if m1[j] < 1e-5 else 1.0, zorder=1.0 if m1[j] < 1e-5 else 2.0) #1f77b4

bases = [
    os.path.join(SATURN_DIR, "14000000_snap.dat"),
    os.path.join(SATURN_DIR, "14230000_snap.dat"),
    os.path.join(SATURN_DIR, "14770000_snap.dat"),
    os.path.join(SATURN_DIR, "16300000_snap.dat"),
    os.path.join(SATURN_DIR, "18600000_snap.dat"),
]
found_files = find_files(bases)

for base, found in found_files.items():
    #print(f"{base} -> {found if found else 'Not found'}")
    if not found:
        continue
    d1 = np.genfromtxt(found)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    t1 = t1 - 6e5
    filtered_t1 = []
    filtered_a1 = []
    filtered_wmf1 = []
    for t, a, w, m in zip(t1, a1, wmf1, m1):
        if m > 1e-5:
            filtered_t1.append(t)
            filtered_a1.append(a)
            filtered_wmf1.append(w)
    ax5.scatter(filtered_t1, filtered_a1, marker='o', c=filtered_wmf1, vmin=0, vmax=0.3, alpha=0.7, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu', zorder=3.0)

file_name = os.path.join(SATURN_DIR, "18707000_snap.dat")
if os.path.exists(file_name):
    d1 = np.genfromtxt(file_name)
    a1, m1, wmf1, t1 = d1.T
    a1 = 20.0 * a1
    mappable = ax6.scatter(m1, a1, marker='o', c=wmf1, vmin=0, vmax=0.3, alpha=1.0, s=100, linewidths=1.0, edgecolors='black', cmap='RdYlBu')  # RdYlBu
else:
    # Keep previous mappable (from ax3) if available, otherwise None.
    pass




ax1.set_title('a', size='16', loc='left', fontweight='bold')
ax1.set_ylabel(r'Semimajor axis ($R_\mathrm{p}$)', size='16')
ax1.set_xlim([1e3,2e5])
ax1.set_ylim([2.9,114])
ax1.set_xscale('log')
ax1.set_yscale('log')
ax1.set_xticks([1e3,1e4,1e5])
ax1.set_xticklabels(['1','10','100'], fontsize='18')
ax1.tick_params(axis='x', labelsize='14')
ax1.set_yticks([3,10,30,100])
ax1.set_yticklabels(['3','10','30','100'], fontsize='14')
ax1.text(2e5,1.80,'Time (kyr)', size=16, ha='center')
ax1.hlines(8.5, 0, 2e5, color='#bcbd22', alpha=0.3, lw=10.0, linestyles='solid')

ax2.set_xlim([1e3,2e5])
ax2.set_ylim([2.9,114])
ax2.set_xscale('log')
ax2.set_yscale('log')
ax2.set_xticks([1e3,1e4,1e5])
ax2.set_xticklabels(['1','10','100'], fontsize='18')
ax2.tick_params(axis='x', labelsize='14')
ax2.tick_params(labelleft=False)

ax3.set_xlabel(r'Mass ($10^{-4} M_\mathrm{p}$)', size='16')
ax3.set_xlim([0,2e-4])#linear
ax3.set_xscale('linear')
ax3.set_yscale('log')
ax3.set_ylim([2.9,114])
ax3.set_xticks([0,1e-4,2e-4])#linear
ax3.set_xticklabels(['0','1','2'], fontsize='16')#linear
ax3.tick_params(axis='x', labelsize='14')
ax3.tick_params(labelleft=False)
ax3.axvspan(1.265e-5, 15.60e-5, (math.log10(2.95)-math.log10(2.9))/(math.log10(114)-math.log10(2.9)), (math.log10(52.8)-math.log10(2.9))/(math.log10(114)-math.log10(2.9)), color ='#7f7f7f', alpha=0.2)


ax4.set_title('b', size='16', loc='left', fontweight='bold')
ax4.set_xlim([1e3,6e5])
ax4.set_ylim([2.9,114])
ax4.set_xscale('log')
ax4.set_yscale('log')
ax4.set_xticks([1e3,1e4,1e5])
ax4.set_xticklabels(['1','10','100'], fontsize='18')
ax4.tick_params(axis='x', labelsize='14')
ax4.text(6e5,1.80,'Time (kyr)', size=16, ha='center')
ax4.tick_params(labelleft=False)

ax5.set_xlim([1e3,2e5])
ax5.set_ylim([2.9,114])
ax5.set_xscale('log')
ax5.set_yscale('log')
ax5.set_xticks([1e3,1e4,1e5])
ax5.set_xticklabels(['1','10','100'], fontsize='18')
ax5.tick_params(axis='x', labelsize='14')
ax5.tick_params(labelleft=False)

ax6.set_xlabel(r'Mass ($10^{-4} M_\mathrm{p}$)', size='16')
ax6.set_xlim([0,2e-4])#linear
ax6.set_xscale('linear')#linear
ax6.set_yscale('log')
ax6.set_ylim([2.9,114])
ax6.set_xticks([0,1e-4,2e-4])#linear
ax6.set_xticklabels(['0','1','2'], fontsize='16')#linear
ax6.tick_params(axis='x', labelsize='14')
ax6.tick_params(labelleft=False)
ax6.axvspan(11.85e-5, 47.40e-5, (math.log10(10.15)-math.log10(2.9))/(math.log10(114)-math.log10(2.9)), (math.log10(40.6)-math.log10(2.9))/(math.log10(114)-math.log10(2.9)), color ='#7f7f7f', alpha=0.2)

axpos = ax3.get_position()
cbar_ax = f.add_axes([axpos.x0-0.04, axpos.y0-0.02, axpos.width*3.0,0.03])
if mappable is None:
    raise FileNotFoundError("No scatter mappable was created (missing snap files).")
cbar = f.colorbar(mappable, cax=cbar_ax, orientation='horizontal')
cbar.set_label("Water mass fraction", fontsize=14)
cbar.ax.tick_params(axis='x', labelsize=14)

plt.subplots_adjust(left=0.06, right=0.99, bottom=0.25, top=0.95, wspace=0.3, hspace=0.1)
plt.savefig('fig4.pdf', transparent=True)
plt.savefig("fig4.jpg", format="jpg", dpi=300)
